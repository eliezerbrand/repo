# -*- coding: utf-8 -*-

import xbmcgui
import xbmcaddon
import os
import pyga.requests as ga
class Addon:
  def __init__(self, id=None ):
    pass
  def run(self):
    addonId     = 'Ninbora.Series_Feeder'
    addon       = xbmcaddon.Addon(id=addonId)
    tracker = ga.Tracker('UA-37624034-2', 'Ninbora.Add' , ga.Config())
    tracker.track_pageview(ga.Page('/Series_Feeder/a1'), ga.Session(), ga.Visitor())
  def service(self):
    self.run()

Addon().run()